package cxx.internal

import kotlinx.css.RuleSet

internal data class Chunk(val query: String, val rule: RuleSet)